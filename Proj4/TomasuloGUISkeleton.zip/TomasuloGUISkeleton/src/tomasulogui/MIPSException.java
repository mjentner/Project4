package tomasulogui;

public class MIPSException extends RuntimeException{
  public MIPSException(String msg) {
     super(msg);
  }
}
