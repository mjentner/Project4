package tomasulogui;

public class MIPSIOException extends RuntimeException {
  public MIPSIOException(String msg) {
     super(msg);
  }
}
